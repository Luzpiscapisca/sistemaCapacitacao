package aplicacao;
import java.util.Scanner;
import entidades.ServidorPublico;
import entidades.Produto;
public class Programa {
    public static void main(String[] args) {
//        ServidorPublico isabela = new ServidorPublico();
//        isabela.setNome("Isabela");
//        isabela.setCargo("Auditor");
//        isabela.setOrgao("ANVISA");
//        isabela.setLotacao("Brasilia");
//        isabela.setEmail("isabela@gmail.");
//
//        ServidorPublico João = new ServidorPublico();
//        ServidorPublico Maria = new ServidorPublico(123, "Maria");
//        ServidorPublico Ana = new ServidorPublico(123, "Ana", "Revisora");
//
//        isabela.setHorasExtras(450);
//        isabela.setSalarioPessoa(2500);
//        isabela.calcularNumeros(3, 7, 9);
//        System.out.println("Servidor: "+ isabela.getNome());
//        System.out.printf("Horas extras R$ %.2f: ",isabela.getHorasExtras());
        Produto produto = new Produto();
        Scanner scr = new Scanner(System.in);
        
    }
}
